<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Specialist;
use App\Appointment;
use Illuminate\Notifications\Notifiable;
class Doctor extends Authenticatable
{
	use Notifiable;

    protected $guarded = [];

    public function specialist(){
    	return $this->belongsTo(Specialist::class);
    }

    public function appointments(){
    	return $this->hasMany(Appointment::class);
    }
}
