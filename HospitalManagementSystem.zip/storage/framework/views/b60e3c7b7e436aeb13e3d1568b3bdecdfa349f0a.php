<?php $__env->startSection('title','Doctor show all Appointments'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
  <div class="card">
    <div class="header">
      <h2>
        Show All Appointmetns

      </h2>

    </div>
    <div class="body table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Visit Date</th>
            <th>Visit Time</th>
            <th>Disease</th>

            <th>Phone Number</th>
            <th>Address</th>
            <th>Status</th>
            <th>Action</th>

          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($loop->index + 1); ?></th>
            <td><?php echo e($appointment->name); ?></td>
            <td><?php echo e($appointment->date); ?>-<?php echo e($appointment->month); ?>-<?php echo e($appointment->year); ?></td>
            <td> <?php
            $time = App\Time::findOrFail($appointment->visit_time); ?>
            <?php echo e($time->time); ?>

          </td>
          <td><?php echo e($appointment->disease); ?></td>

          <td><?php echo e($appointment->phone_number); ?></td>
          <td><?php echo e($appointment->address); ?>


          </td>
          <td><?php echo e($appointment->status === 1 ? 'Complete' : 'Incomplete'); ?></td>


          <td>

            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#patient_<?php echo e($appointment->id); ?>">
              <i class="fa fa-eye"></i>
            </button>

            <button class="btn btn-danger btn-sm" type="button" onclick="deleteappointment(<?php echo e($appointment->id); ?>)">
              <i class="fa fa-trash"></i>
            </button>



            <form id="delete_form_<?php echo e($appointment->id); ?>" method="post" action="<?php echo e(route('doctor.deleteAppointment',['id'=>$appointment->id])); ?>" style="display: none;">
              <?php echo method_field('DELETE'); ?>
              <?php echo csrf_field(); ?>

            </form>
          </td>






          <!-- Button trigger modal -->


          <!-- Modal -->
          <div class="modal fade" id="patient_<?php echo e($appointment->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Appointment Patient</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <div class="row">

                    <h4><strong>Patient Name : </strong><?php echo e($appointment->name); ?></h4>
                    <h4><strong>Visit Date: </strong><?php echo e($appointment->date); ?>-<?php echo e($appointment->month); ?>-<?php echo e($appointment->year); ?></h4>
                    <h4><strong>Visit Time: </strong><?php
                    $time = App\Time::findOrFail($appointment->visit_time);
                    $day = App\Day::findOrFail($appointment->day); ?>
                    <?php echo e($time->time); ?> <strong>(<?php echo e($day->day); ?>)</strong></h4>

                    <h4><strong>Disease : </strong><?php echo e($appointment->disease); ?></h4>
                    <h4><strong>Fee : </strong><?php echo e($appointment->doctor_fee); ?></h4>

                    <h4><strong>Address : </strong><?php echo e($appointment->address); ?></h4>

                    <h4><strong>Mobile Number : </strong><?php echo e($appointment->phone_number); ?></h4>

                    <a href="<?php echo e(route('doctor.updateAppointment',['id'=>$appointment->id])); ?>" class="btn btn-info"><?php echo e($appointment->status === 1 ? 'completed' : 'incomplete'); ?></a>

                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

                </div>
              </div>
            </div>
          </div>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

<script src="https://unpkg.com/sweetalert2@7.19.1/dist/sweetalert2.all.js"></script>

<script src="https://use.fontawesome.com/3d1aefa331.js"></script>

<script type="text/javascript">
  function deleteappointment(id) {
    swal({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success',
      cancelButtonClass: 'btn btn-danger',
      buttonsStyling: false,
      reverseButtons: true
    }).then((result) => {
      if (result.value) {
        event.preventDefault();
        document.getElementById('delete_form_'+id).submit();
      } else if (
                    // Read more about handling dismissals
                    result.dismiss === swal.DismissReason.cancel
                    ) {
        swal(
          'Cancelled',
          'Your data is safe :)',
          'error'
          )
      }
    })
  }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backEnd.doctor.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel_workfile\HospitalManagementSystem\resources\views/backEnd/doctor/pages/appointment/index.blade.php ENDPATH**/ ?>