<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <h2>DASHBOARD</h2>
    </div>

    <!-- Widgets -->
    <div class="row clearfix">
        <a href="<?php echo e(route('doctor.appointment.index')); ?>"  style="cursor:pointer">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="info-box bg-pink hover-expand-effect">
                    <div class="icon">
                        <i class="material-icons">playlist_add_check</i>
                    </div>
                    <div class="content">
                        <div class="text">My Patients</div>
                        <div class="number count-to" data-from="0" data-to="<?php echo e(count(App\Doctor::findOrFail(Auth::id())->appointments)); ?>" data-speed="15" data-fresh-interval="20"></div>
                    </div>
                </div>
            </div>
        </a>




</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.doctor.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel_workfile\HospitalManagementSystem\resources\views/backEnd/doctor/pages/dashboard.blade.php ENDPATH**/ ?>