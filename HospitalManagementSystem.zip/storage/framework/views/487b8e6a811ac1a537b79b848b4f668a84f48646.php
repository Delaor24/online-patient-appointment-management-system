<?php $__env->startSection('title','Specialist Doctor List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	
	<div class="row mt-2">
		<img src="<?php echo e(asset('backEnd/images/banner.jpg')); ?>" width="100%" class="img-fluid" style="height: 200px!important">
	</div>
	
</div>

<div class="container">

	<h3 class="mt-2" style="text-align: center;color: #40B176"><strong>Specialist - </strong><?php echo e($specialist->name); ?></h3>
		<hr>
      <?php if(count($doctors) > 0): ?>
	<div class="row mt-1">
		<?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-md-6 mb-3">
			<div class="card p-2">
				
				<div class="row">

					
					<div class="col-md-4">
						<img src="<?php if(isset($doctor->avatar)): ?> <?php echo e(Storage::disk('public')->url('profile/'.$doctor->avatar)); ?>  <?php else: ?> <?php echo e(asset('backEnd/images/user.png')); ?> <?php endif; ?>" class="img-fluid" width="100%" style="height:158px!important">
					</div>
					<div class="col-md-8">
						<h3 class="text-danger"><strong><?php echo e($doctor->name); ?></strong></h3>
						<h6 style="color: black"><strong>Specialty -</strong> <?php echo e($doctor->specialist->name); ?></h6>
						<h6 style="color: black"><strong>Degree - </strong> <?php echo e($doctor->degree); ?></h6>

						<div class="mt-5">
							<a href="<?php echo e(route('frontEnd.appointment.create',['id'=>$doctor->id,'title'=>$doctor->name])); ?>" class="btn btn-success btn-sm">Get Appointment</a>
							<a href="<?php echo e(route('doctor.singlePage',['id'=>$doctor->id])); ?>" class="btn btn-success btn-sm">View Details</a>
						</div>
					</div>
					
				</div>

				
			</div>
		</div>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</div>
	<?php else: ?>
	<h3 class="mt-2" style="text-align: center;color: red"><strong>Doctors Not Found!! - </strong></h3>
	<?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel_workfile\HospitalManagementSystem\resources\views/frontEnd/pages/specialist-doctor-list.blade.php ENDPATH**/ ?>