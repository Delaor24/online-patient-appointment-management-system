      <aside id="leftsidebar" class="sidebar">
        <!-- User Info -->

        <div class="user-info">
            <div class="image">
                <img src="<?php if(isset(Auth::user()->avatar)): ?><?php echo e(Storage::disk('public')->url('profile/'.Auth::user()->avatar)); ?><?php else: ?> <?php echo e(asset('backEnd/profile/profile.jpg')); ?><?php endif; ?>" width="48" height="48" alt="User"/>
            </div>
            
            <div class="info-container">

                <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></div>
                <div class="email"><?php echo e(Auth::user()->email); ?></div>
                <div class="btn-group user-helper-dropdown">
                    <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                    <ul class="dropdown-menu pull-right">
                        <li><a href="<?php echo e(route('admin.profile')); ?>"><i class="material-icons">person</i>Profile</a></li>


                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('admin.logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            <i class="material-icons">input</i>Sign Out
                        </a>

                        <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>

                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- #User Info -->
    <!-- Menu -->
    <div class="menu">
        <ul class="list">
            <li class="header">MAIN NAVIGATION</li>
            <li class="<?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="material-icons">home</i>
                    <span>Dashboard</span>
                </a>
            </li>

            <li class="<?php echo e(Request::is('admin/specialists*') ? 'active' : ''); ?>">
               <a href="javascript:void(0);" class="menu-toggle">
                <i class="material-icons">view_list</i>
                <span>specialist</span>
            </a>
            <ul class="ml-menu">
                <li>
                    <a href="<?php echo e(route('specialists.create')); ?>">Specialist create</a>
                </li>
                <li>
                    <a href="<?php echo e(route('specialists.index')); ?>">Specialist all</a>
                </li>

            </ul>
        </li>

  

    <?php if(Auth::user()->type == 'admin'): ?>
    <li class="<?php echo e(Request::is('admin/doctors*') ? 'active' : ''); ?>">
           <a href="javascript:void(0);" class="menu-toggle">
            <i class="material-icons">view_list</i>
            <span>Doctors</span>
        </a>
        <ul class="ml-menu">
            <li>
                <a href="<?php echo e(route('doctors.create')); ?>">Add Doctor</a>
            </li>
            <li>
                <a href="<?php echo e(route('doctors.index')); ?>">View Doctor List</a>
            </li>

            <li>
                <a href="<?php echo e(route('doctordays.create')); ?>">Add Doctor Working Day</a>
            </li>

            <li>
                <a href="<?php echo e(route('doctortimes.create')); ?>">Add Doctor Visit Time</a>
            </li>

        </ul>
    </li>

    <?php endif; ?>

        <li class="<?php echo e(Request::is('admin/appointments*') ? 'active' : ''); ?>">
           <a href="javascript:void(0);" class="menu-toggle">
            <i class="material-icons">view_list</i>
            <span>Appointments</span>
        </a>
        <ul class="ml-menu">
            <li>
                <a href="<?php echo e(route('appointments.create')); ?>">Add New Appointment</a>
            </li>
            <li>
                <a href="<?php echo e(route('appointments.index')); ?>">View Appointment List</a>
            </li>

        </ul>
    </li>


          <li class="<?php echo e(Request::is('admin/staffs*') ? 'active' : ''); ?>">
           <a href="javascript:void(0);" class="menu-toggle">
            <i class="material-icons">view_list</i>
            <span>Staffs</span>
        </a>
        <ul class="ml-menu">
            <li>
                <a href="<?php echo e(route('staffs.create')); ?>">Staff create</a>
            </li>
            <li>
                <a href="<?php echo e(route('staffs.index')); ?>">Staff all</a>
            </li>

        </ul>
    </li>


          <li class="<?php echo e(Request::is('admin/contact*') ? 'active' : ''); ?>">
           <a href="javascript:void(0);" class="menu-toggle">
            <i class="material-icons">view_list</i>
            <span>Incomming Mail</span>
        </a>
        <ul class="ml-menu">
            <li>
                <a href="<?php echo e(route('admin.contactUs')); ?>">Contact Lists</a>
            </li>
         

        </ul>
    </li>


    <li class="<?php echo e(Request::is('admin/setting*') ? 'active' : ''); ?>">
       <a href="javascript:void(0);" class="menu-toggle">
        <i class="material-icons">view_list</i>
        <span>Setting</span>
    </a>
    <ul class="ml-menu">
        <li>
            <a href="<?php echo e(route('admin.profile')); ?>">Profile</a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('admin.logout')); ?>"
            onclick="event.preventDefault();
            document.getElementById('logout-form').submit();">
            <i class="material-icons">input</i>Sign Out
        </a>

        <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>



    </li>

</ul>
</li>



</ul>
</div>
<!-- #Menu -->
<!-- Footer -->
<div class="legal">
    <div class="copyright">
        &copy; <?php echo date('Y') ?> <a href="javascript:void(0);">Material Design</a>.
    </div>
    <div class="version">
        <b>Version: </b> 1.0.5
    </div>
</div>
<!-- #Footer -->
</aside><?php /**PATH E:\xampp\htdocs\laravel_workfile\HospitalManagementSystem\resources\views/backEnd/admin/layout/partial/leftSidebar.blade.php ENDPATH**/ ?>