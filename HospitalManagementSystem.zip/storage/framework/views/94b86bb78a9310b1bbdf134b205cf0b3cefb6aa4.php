<?php $__env->startSection('title','appointment create'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	
	<div class="row mt-2">
		<img src="<?php echo e(asset('backEnd/images/banner.jpg')); ?>" width="100%" class="img-fluid" style="height: 200px!important">
	</div>
	
</div>

<div class="container">
	<div class="row">
		<div class="col-8 offset-2">
			<h3 class="text-center text-info py-3">Appointment</h3>
			<hr>
			<div>


				<form method="POST" action="<?php echo e(route('frontEnd.appointment.store')); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="col-sm-12">
						<div class="form-group">
							<div class="form-line">
								<label><strong>Name</strong> <span style="color: red">*</span></label>
								<input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" placeholder="Patient Name" value="<?php echo e(old('name')); ?>">
								<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>

						<div class="form-group">
							<div class="form-line">
								<label><strong>Disease Name</strong> <span style="color: red">*</span></label>
								<input type="text" class="form-control <?php $__errorArgs = ['disease'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="disease" placeholder="What is your problem? disease" value="<?php echo e(old('disease')); ?>">
								<?php $__errorArgs = ['disease'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>

						<input type="hidden"  class="form-control" value="<?php echo e($doctorSelect->id); ?>" name="doctor_id">



						<div class="form-group">
							<div class="form-line">
								<label><strong>These days doctor available</strong></label>
								<input type="text"  class="form-control" disabled  value="<?php echo e($doctorSelect->day); ?>">

							</div>
						</div>






						<div class="form-group">
							<div class="form-line">
								<label><strong>Which day you want to appointment?</strong> <span style="color: red">*</span></label>

								
								
								<div class="row">
									<div class="col-md-3">
										<label>Date <span style="color: red">*</span></label>
										<select class="form-control" name="date">
											<option value="1" <?php $month =  Date('d'); $m = strcmp($month,'1'); if($m == 0) { echo 'selected'; }?>>1</option>
											<option value="2" <?php $month =  Date('d'); $m = strcmp($month,'2'); if($m == 0) { echo 'selected'; }?>>2</option>
											<option value="3" <?php $month =  Date('d'); $m = strcmp($month,'3'); if($m == 0) { echo 'selected'; }?>>3</option>
											<option value="4" <?php $month =  Date('d'); $m = strcmp($month,'4'); if($m == 0) { echo 'selected'; }?>>4</option>
											<option value="5" <?php $month =  Date('d'); $m = strcmp($month,'5'); if($m == 0) { echo 'selected'; }?>>5</option>
											<option value="6" <?php $month =  Date('d'); $m = strcmp($month,'6'); if($m == 0) { echo 'selected'; }?>>6</option>
											<option value="7" <?php $month =  Date('d'); $m = strcmp($month,'7'); if($m == 0) { echo 'selected'; }?>>7</option>
											<option value="8" <?php $month =  Date('d'); $m = strcmp($month,'8'); if($m == 0) { echo 'selected'; }?>>8</option>
											<option value="9" <?php $month =  Date('d'); $m = strcmp($month,'9'); if($m == 0) { echo 'selected'; }?>>9</option>
											<option value="10" <?php $month =  Date('d'); $m = strcmp($month,'10'); if($m == 0) { echo 'selected'; }?>>10</option>
											<option value="11" <?php $month =  Date('d'); $m = strcmp($month,'11'); if($m == 0) { echo 'selected'; }?>>11</option>
											<option value="12" <?php $month =  Date('d'); $m = strcmp($month,'12'); if($m == 0) { echo 'selected'; }?>>12</option>
											<option value="13" <?php $month =  Date('d'); $m = strcmp($month,'13'); if($m == 0) { echo 'selected'; }?>>13</option>
											<option value="14" <?php $month =  Date('d'); $m = strcmp($month,'14'); if($m == 0) { echo 'selected'; }?>>14</option>
											<option value="15" <?php $month =  Date('d'); $m = strcmp($month,'15'); if($m == 0) { echo 'selected'; }?>>15</option>
											<option value="16" <?php $month =  Date('d'); $m = strcmp($month,'16'); if($m == 0) { echo 'selected'; }?>>16</option>
											<option value="17" <?php $month =  Date('d'); $m = strcmp($month,'17'); if($m == 0) { echo 'selected'; }?>>17</opti9on>
											<option value="18" <?php $month =  Date('d'); $m = strcmp($month,'18'); if($m == 0) { echo 'selected'; }?>>18</option>

											<option value="19" <?php $month =  Date('d'); $m = strcmp($month,'19'); if($m == 0) { echo 'selected'; }?>>19</option>
											<option value="20" <?php $month =  Date('d'); $m = strcmp($month,'20'); if($m == 0) { echo 'selected'; }?>>20</option>
											<option value="21" <?php $month =  Date('d'); $m = strcmp($month,'21'); if($m == 0) { echo 'selected'; }?>>21</option>
											<option value="22" <?php $month =  Date('d'); $m = strcmp($month,'22'); if($m == 0) { echo 'selected'; }?>>22</option>
											<option value="23" <?php $month =  Date('d'); $m = strcmp($month,'23'); if($m == 0) { echo 'selected'; }?>>23</option>
											<option value="24" <?php $month =  Date('d'); $m = strcmp($month,'24'); if($m == 0) { echo 'selected'; }?>>24</option>
											<option value="25" <?php $month =  Date('d'); $m = strcmp($month,'25'); if($m == 0) { echo 'selected'; }?>>25</opti9on>
											<option value="26" <?php $month =  Date('d'); $m = strcmp($month,'26'); if($m == 0) { echo 'selected'; }?>>26</option>

											<option value="27" <?php $month =  Date('d'); $m = strcmp($month,'27'); if($m == 0) { echo 'selected'; }?>>27</option>
											<option value="28" <?php $month =  Date('d'); $m = strcmp($month,'28'); if($m == 0) { echo 'selected'; }?>>28</option>
											<option value="29" <?php $month =  Date('d'); $m = strcmp($month,'29'); if($m == 0) { echo 'selected'; }?>>29</option>
											<option value="30" <?php $month =  Date('d'); $m = strcmp($month,'30'); if($m == 0) { echo 'selected'; }?>>30</option>
											<option value="31" <?php $month =  Date('d'); $m = strcmp($month,'31'); if($m == 0) { echo 'selected'; }?>>31</option>

										
										</select>
									</div>	
									<div class="col-md-3">
										<label>Day <span style="color: red">*</span></label>
										<select class="form-control" id="day_id" name="day">
											<option value="0">select day</option>
											<?php $__currentLoopData = App\Doctor::findOrFail($doctorSelect->id)->days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($day->id); ?>"><?php echo e($day->day); ?></option>


											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</select>

									</div>	
									<div class="col-md-3">
										<label>Month <span style="color: red">*</span></label>
										<select class="form-control" name="month">
											<option value="1" <?php $month =  Date('F'); $m = strcmp($month,'January'); if($m == 0) { echo 'selected'; }?>>January</option>
											<option value="2" <?php $month =  Date('F'); $m = strcmp($month,'February'); if($m == 0) { echo 'selected'; }?>>February</option>
											<option value="3" <?php $month =  Date('F'); $m = strcmp($month,'March'); if($m == 0) { echo 'selected'; }?>>March</option>
											<option value="4" <?php $month =  Date('F'); $m = strcmp($month,'April'); if($m == 0) { echo 'selected'; }?>>April</option>
											<option value="5" <?php $month =  Date('F'); $m = strcmp($month,'May'); if($m == 0) { echo 'selected'; }?>>May</option>
											<option value="6" <?php $month =  Date('F'); $m = strcmp($month,'June'); if($m == 0) { echo 'selected'; }?>>June</option>
											<option value="7" <?php $month =  Date('F'); $m = strcmp($month,'July'); if($m == 0) { echo 'selected'; }?>>July</option>
											<option value="8" <?php $month =  Date('F'); $m = strcmp($month,'August'); if($m == 0) { echo 'selected'; }?>>August</option>
											<option value="9" <?php $month =  Date('F'); $m = strcmp($month,'September'); if($m == 0) { echo 'selected'; }?>>september</option>
											<option value="10" <?php $month =  Date('F'); $m = strcmp($month,'Octorber'); if($m == 0) { echo 'selected'; }?>>Octorber</option>
											<option value="11" <?php $month =  Date('F'); $m = strcmp($month,'November'); if($m == 0) { echo 'selected'; }?> >November</option>
											<option value="12" <?php $month =  Date('F'); $m = strcmp($month,'December'); if($m == 0) { echo 'selected'; }?>>December</option>

										</select>

									</div>	
									<div class="col-md-3">
										<label>Year <span style="color: red">*</span></label>
										<select class="form-control" name="year">
											<option>2019</option>
											<option>2020</option>

										</select>

									</div>	
								</div>
							</div>
						</div>

						<div class="form-group">
							<div class="form-line">
								<label><strong>When you want to appointment?</strong> <span style="color: red">*</span></label>
								<select class="form-control" name="visit_time" id="time_id">


								</select>
							</div>
						</div>






				



			





						<div class="form-group">
							<div class="form-line">

								<label><strong>Doctor Fee</strong> <span style="color: red">*</span></label>
								<input type="text" class="form-control <?php $__errorArgs = ['doctor_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="doctor_fee" value="BDT: 700 Tk" placeholder="Doctor visit (fee = 700 Tk)">

								<?php $__errorArgs = ['doctor_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>



						


						<div class="form-group">
							<div class="form-line">

								<label><strong>Mobile Number</strong> <span style="color: red">*</span></label>
								<input type="text" class="form-control <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone_number" placeholder="phone number" value="<?php echo e(old('phone_number')); ?>">

								<?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>


						<div class="form-group">
							<div class="form-line">
								<label><strong>Address</strong> <span style="color: red">*</span></label>
								<input type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address" placeholder="Address" value="<?php echo e(old('address')); ?>">

								<?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>


						<div class="form-group">
							<button type="submit" class="btn btn-success">Appointment Send</button>
						</div>
					</div>




				</form>


				
			</div>
			
			
		</div>
		
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script type ="text/javascript">
	$(function() {
		$("#day_id").change(function(){
			var day_id = $("#day_id").val();

            


        //send an ajax request to the  server with this division
        
        $("#time_id").html("");

        var option = "";

        $.get("http://127.0.0.1:8000/appointment/"+day_id,

        	function(data){
        		data = JSON.parse(data);

        		if(data == 0){
        			alert("No Time Added For this Day");
        		}else{
        			data.forEach(function(element){
        			option+= "<option value='"+element.id+"'>"+ element.time +"</option>";
        		});

        		$("#time_id").html(option);
        		}
        		

        	});


        });
	});



</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontEnd.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel_workfile\HospitalManagementSystem\resources\views/frontEnd/pages/appointment/create.blade.php ENDPATH**/ ?>