<?php $__env->startSection('title','show all Appointments'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Show All Appointments
                                
                            </h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                   <a href="<?php echo e(route('appointments.create')); ?>" class="btn btn-info">Add New Appointment</a>
                                </li>
                            </ul>
                        </div>
                        <div class="body table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Visit Date</th>
                                        <th>Visit Time</th>
                                        <th>Disease</th>

                                        <th>Doctor</th>
                                        <th>Phone Number</th>
                                        <th>Address</th>
                                
                                        <th>Action</th>
                                   
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                        <td><?php echo e($appointment->name); ?></td>
                                         <td><?php echo e($appointment->visit_day); ?></td>
                                         <td><?php echo e($appointment->visit_time); ?></td>
                                        <td><?php echo e($appointment->disease); ?></td>
                                        <td><?php echo e($appointment->doctor->name); ?></td>
                                        <td><?php echo e($appointment->phone_number); ?></td>
                                        <td><?php echo e($appointment->address); ?></td>
                                       
                                 
                                        <td>
                                        	<a href="<?php echo e(route('appointments.edit',['appointment'=>$appointment->id])); ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i></a>

                                        	<button class="btn btn-danger btn-sm" type="button" onclick="deleteappointment(<?php echo e($appointment->id); ?>)">
                          <i class="fa fa-trash"></i>
                    </button>
                  


		                  	<form id="delete_form_<?php echo e($appointment->id); ?>" method="post" action="<?php echo e(route('appointments.destroy',['appointment'=>$appointment->id])); ?>" style="display: none;">
		                  		<?php echo method_field('DELETE'); ?>
		                  		<?php echo csrf_field(); ?>

		                  	</form>
                                        </td>
                                        
                                    </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

<script src="https://unpkg.com/sweetalert2@7.19.1/dist/sweetalert2.all.js"></script>

 <script src="https://use.fontawesome.com/3d1aefa331.js"></script>

 <script type="text/javascript">
        function deleteappointment(id) {
            swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                confirmButtonClass: 'btn btn-success',
                cancelButtonClass: 'btn btn-danger',
                buttonsStyling: false,
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete_form_'+id).submit();
                } else if (
                    // Read more about handling dismissals
                    result.dismiss === swal.DismissReason.cancel
                ) {
                    swal(
                        'Cancelled',
                        'Your data is safe :)',
                        'error'
                    )
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backEnd.admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel_workfile\HospitalManagementSystem\resources\views/backEnd/admin/pages/appointment/index.blade.php ENDPATH**/ ?>