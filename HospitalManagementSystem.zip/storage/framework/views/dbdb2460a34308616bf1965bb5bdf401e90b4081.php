<?php $__env->startSection('title','Doctor show single appointment'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-2">
	
		<h4><strong>Patient Name : </strong><?php echo e($appointment->name); ?></h4>
                    <h4><strong>Visit Date: </strong><?php echo e($appointment->date); ?>-<?php echo e($appointment->month); ?>-<?php echo e($appointment->year); ?></h4>
                    <h4><strong>Visit Time: </strong><?php
                    $time = App\Time::findOrFail($appointment->visit_time);
                    $day = App\Day::findOrFail($appointment->day); ?>
                    <?php echo e($time->time); ?> <strong>(<?php echo e($day->day); ?>)</strong></h4>

                    <h4><strong>Disease : </strong><?php echo e($appointment->disease); ?></h4>
                    <h4><strong>Fee : </strong><?php echo e($appointment->doctor_fee); ?></h4>

                    <h4><strong>Address : </strong><?php echo e($appointment->address); ?></h4>

                    <h4><strong>Mobile Number : </strong><?php echo e($appointment->phone_number); ?></h4>

                    <a href="<?php echo e(route('doctor.updateAppointment',['id'=>$appointment->id])); ?>" class="btn btn-info"><?php echo e($appointment->status === 1 ? 'completed' : 'incomplete'); ?></a>

		<a href="<?php echo e(route('doctor.appointment.index')); ?>" class="btn btn-success">Back</a>
	

</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('backEnd.doctor.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel_workfile\HospitalManagementSystem\resources\views/backEnd/doctor/pages/appointment/single-view.blade.php ENDPATH**/ ?>